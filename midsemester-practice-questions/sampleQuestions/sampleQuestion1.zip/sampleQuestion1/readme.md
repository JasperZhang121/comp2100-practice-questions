## Software Testing Practice
This is a lab from a previous semester. It is provided here as extra practice for the mid-semester exam.
* * *
The exercise is very similar to Task1 in Lab3 (Software Testing). The only significant differences between this exersize and Task1 of Lab3 is that there are more mark calculators and some of the mark calculators are different (hence the correct mark calculator might be different). Everything else in this exercise is the same as Task1 in Lab3 - please refer to the Lab3 manual (available in the course Gitlab repository). 