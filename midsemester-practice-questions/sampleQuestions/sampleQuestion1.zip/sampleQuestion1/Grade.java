public enum Grade {
     N, NCN, PX, P, C, D, HD;
}
